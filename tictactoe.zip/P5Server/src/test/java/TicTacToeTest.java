import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TicTacToeTest 
{
	static FindNextMove nm;
	
	@BeforeAll
	static void setup()
	{
		//create an instance of find next move to use for all the tests
		nm = new FindNextMove();
	}
	
	//test that min max find next move class it initialized correctly
	@Test
	void testFindNextMoveInit()
	{
		assertEquals("FindNextMove", nm.getClass().getName(), "FindNextMove not initialized correctly");
	}
	
	//test that min max will put X in middle for its first move if middle not taken
	@Test
	void testFirstMiddle()
	{
		//set up initial board
		// initial board is:
		// O b b
		// b b b
		// b b b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 0)
				board[i] = "O";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		System.out.println(nextMove);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[4], "min max did not put X in middle!");
	}
	
	//test that if theres an option to block an O win or take an X win, min max takes win
	@Test
	void testWinOverBlock()
	{
		//set up initial board
		// initial board is:
		// O X O
		// b b b
		// O X b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 0 || i == 2 || i == 6)
				board[i] = "O";
			else if(i == 7 || i == 1)
				board[i] = "X";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[4], "min max did not put X in middle!");
	}
	
	//if there are X's on top and bottom, min max puts X in middle to take win
	@Test
	void testTakeVerticalWin()
	{
		//set up initial board
		// initial board is:
		// O X b
		// O b O
		// b X b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 0 || i == 3 || i == 5)
				board[i] = "O";
			else if(i == 7 || i == 1)
				board[i] = "X";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[4], "min max did not put X in middle!");
	}
	
	//test that if theres an X in each corner, min max puts X in middle to take win
	@Test
	void testTakeDiagonalWin()
	{
		//set up initial board
		// initial board is:
		// O b X
		// O b O
		// X b b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 0 || i == 3 || i == 5)
				board[i] = "O";
			else if(i == 2 || i == 6)
				board[i] = "X";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[4], "min max did not put X in middle!");
	}
	
	//test that if theres an X on left and right side, min max puts X in middle to win
	@Test
	void testTakeHorizontalWin()
	{
		//set up initial board
		// initial board is:
		// O b O
		// X b X
		// b O b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 3 || i == 5)
				board[i] = "X";
			else if(i == 0 || i == 2 || i == 7)
				board[i] = "O";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[4], "min max did not put X in middle!");
	}

	
	//test that if O has way to win diagonally, min max blocks the win
	@Test
	void testBlockDiagWin()
	{
		//set up initial board
		// initial board is:
		// b X O
		// O O X
		// b b b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 1 || i == 5)
				board[i] = "X";
			else if(i == 2 || i == 3 || i == 4)
				board[i] = "O";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[6], "min max did not block win!");
		
	}
	
	//test that if O has way to win horizontally, min max blocks the win
	@Test
	void testBlockHorizontalWin()
	{
		//set up initial board
		// initial board is:
		// O b O
		// b X b
		// b b b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 0 || i == 2)
				board[i] = "O";
			else if(i == 4)
				board[i] = "X";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		System.out.println("NETX MOVE IS: " + nextMove);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[1], "min max did not block win!");
		
	}
	
	//test that if O has way to win vertically, min max blocks the win
	@Test
	void testBlockVerticalWin()
	{
		//set up initial board
		// initial board is:
		// O b b
		// b X b
		// O b b
		String[] board = new String[9];
		for(int i = 0; i < 9; i++)
		{
			if(i == 0 || i == 6)
				board[i] = "O";
			else if(i == 4)
				board[i] = "X";
			else
				board[i] = "b";
		}
		
		//get the next move
		int nextMove = nm.getExpertMove(board);
		System.out.println("NETX MOVE IS: " + nextMove);
		board[nextMove] = "X";
		
		//check correct move was made
		assertEquals("X", board[3], "min max did not block win!");
	}
}
