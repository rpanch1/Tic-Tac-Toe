import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.Consumer;

public class TTTServer
{
	//hashmap that maps client id number to clientthread for that client
	HashMap<Integer, ClientThread> clients;
	
	//number of connected clients
	static int clientCount;
	
	//array list of client numbers that have been used but are now available
	static ArrayList<Integer> availableIDs;
	
	//instance of server
	static TheServer server;
	
	//hashmap holds the connected/ waiting/ ingame status for each client
	HashMap<Integer, Integer> clientInfo;
	
	//consumer to update the gui when the server starts successfully
	private Consumer<Serializable> success;
	
	//consumer to update the gui when the server starts unsuccessfully
	private Consumer<Serializable> fail;
	
	//consumer to update the server log when new events happen
	private Consumer<HashMap<Integer, Integer>> guiUpdate;
	
	//consumer to update server log list in the gui with messages
	private Consumer<String> listUpdate;
	
	//instance of find next move for using min/max algorithm
	FindNextMove nextMove;
	
	int portNumber;
	
	TTTServer(Consumer<Serializable> s, Consumer<Serializable> f, Consumer<HashMap<Integer, Integer>> g, Consumer<String> l, int port)
	{
		clientCount = 0;
		clients = new HashMap<Integer, ClientThread>();
		clientInfo = new HashMap<Integer, Integer>();
		
		availableIDs = new ArrayList<Integer>();
		
		success = s;
		fail = f;
		guiUpdate = g;
		listUpdate = l;
		
		portNumber = port;
		
		server = new TheServer();
		server.setDaemon(true);
		server.start();
		
		nextMove = new FindNextMove();
		
		//gameInfo = new GameInfo(0, 0, "notConnected", "notConnected", false, false);
	}
	
	void addToIDs(int num)
	{
		availableIDs.add(num);
	}
	
	public class TheServer extends Thread
	{
		
		public void run() 
		{
		
			try(ServerSocket mysocket = new ServerSocket(portNumber);)
			{
				//update gui for successful start
				success.accept(1);
				
				System.out.println("Server is waiting for a client!");
			
				while(true) 
				{	
					clientCount++;
					
					//figure out what number id this client will have. reuse an old one if there are any
					//if not, give it a new number that is the number of clients connected
					int numberToAssign;
					if(availableIDs.size() == 0)
					{
						numberToAssign = clientCount;
					}
					else
					{
						numberToAssign = availableIDs.get(0);
						availableIDs.remove(0);
					}
					
					//create a new client thread, add it to clients array list, and start the thread
					ClientThread c = new ClientThread(mysocket.accept(), numberToAssign);
					clients.put(numberToAssign, c);
					c.setDaemon(true);
					c.start();
					
					//add the client to the hashmap as connected and not in game
					clientInfo.put(numberToAssign, 0);
					
			    }
			}
			catch(Exception e) 
			{
				System.out.println("server socket did not launch");
			
				//update gui for failed server launch
				fail.accept(1);
			}
		}
	}
	

	class ClientThread extends Thread
	{
		Socket connection;
		int clientNum; //identifier for which client this is
		ObjectInputStream in;
		ObjectOutputStream out;
		
		ClientThread(Socket s, int clientNum)
		{
			this.connection = s;
			this.clientNum = clientNum;
		}
		
		//returns 0 if no winner, 1 if player won, 2 if server won, 3 if draw
		int checkGameStatus(String[] board)
		{
			//check for horizontal across top
			if(board[0].equals(board[1]) && board[1].equals(board[2]) && !(board[0].equals("b")))
			{
				//check if player
				if(board[0].equals("O")) return 1;
				else return 2;
			}
			
			//check for horizontal across middle
			else if(board[3].equals(board[4]) && board[4].equals(board[5]) && !(board[3].equals("b")))
			{
				//check if player
				if(board[3].equals("O")) return 1;
				else return 2;
			}
			
			//check for horizontal across bottom
			else if(board[6].equals(board[7]) && board[7].equals(board[8]) && !(board[6].equals("b")))
			{
				//check if player
				if(board[6].equals("O")) return 1;
				else return 2;
			}
			
			//check for vertical across left
			else if(board[0].equals(board[3]) && board[3].equals(board[6]) && !(board[0].equals("b")))
			{
				//check if player
				if(board[0].equals("O")) return 1;
				else return 2;
			}
			
			//check for vertical across middle
			else if(board[1].equals(board[4]) && board[4].equals(board[7]) && !(board[1].equals("b")))
			{
				//check if player
				if(board[1].equals("O")) return 1;
				else return 2;
			}
			
			//check for vertical across right
			else if(board[2].equals(board[5]) && board[5].equals(board[8]) && !(board[2].equals("b")))
			{
				//check if player
				if(board[2].equals("O")) return 1;
				else return 2;
			}
			
			//check for diagonal top left to bot right
			else if(board[0].equals(board[4]) && board[4].equals(board[8]) && !(board[0].equals("b")))
			{
				//check if player
				if(board[0].equals("O")) return 1;
				else return 2;
			}
			
			//check for diagonal top right to bot left
			else if(board[2].equals(board[4]) && board[4].equals(board[6]) && !(board[2].equals("b")))
			{
				//check if player
				if(board[2].equals("O")) return 1;
				else return 2;
			}
			
			//otherwise its a draw or no winner yet
			else
			{
				//if theres an empty spot, then no winner. otherwise draw
				for(int i = 0; i < 9; i++)
				{
					if(board[i].equals("b")) 
						return 0;
				}
				
				//board is full, draw
				return 3;
			}
		}
		
		//returns a tic tac toe board with all blank spaces
		String[] getBlankBoard()
		{
			String[] newB = new String[9];
			
			for(int i = 0; i < 9; i++)
				newB[i] = "b";
			
			return newB;
		}
		
		//returns a hashmap of the 3 clients with the highest score
		HashMap<Integer, Integer> getTop3()
		{
			HashMap<Integer, Integer> top3 = new HashMap<Integer, Integer>();
			
			//list of all connected client numbers
			ArrayList<Integer> keys = new ArrayList<Integer>(clients.keySet());
			
			int t1c = -1;
			int t1v = 0;
			int t2c = -1;
			int t2v = 0;
			int t3c = -1;
			int t3v = 0;
			
			for(int i = 0; i < keys.size(); i++)
			{
				int thisKey = keys.get(i);
				
				//if current clients score is higher than 1st place, replace 1st
				if(clientInfo.get(thisKey) > t1v)
				{
					//percolate the previous top score down
					t3c = t2c;
					t3v = t2v;
					t2c = t1c;
					t2v = t1v;
					
					//set the new 1st place to this client
					t1c = thisKey;
					t1v = clientInfo.get(thisKey);	
				}
				//if this client is smaller than 1st place but larger than second
				else if(clientInfo.get(thisKey) > t2v)
				{
					//percolate second place down to third
					t3c = t2c;
					t3v = t2v;
					
					//replace second place
					t2c = thisKey;
					t2v = clientInfo.get(thisKey);
				}
				//if this client is smaller than first and second, but larger than third
				else if(clientInfo.get(thisKey) > t3v)
				{
					//replace third place
					t3c = thisKey;
					t3v = clientInfo.get(thisKey);
				}
			}
			
			//place all scores into the hashmap
			if(t1c != -1)
				top3.put(t1c, t1v);
			if(t2c != -1)
				top3.put(t2c, t2v);
			if(t3c != -1)
				top3.put(t3c, t3v);
			
			//return the hashmap
			return top3;
		}
		
		//sends gameinfo object gi to all connected clients
		void sendToAll(GameInfo gi)
		{
			
			//list of keys in clientInfo
			ArrayList<Integer> keys = new ArrayList<Integer>(clients.keySet());
			
			//iterate through all keys and send object to connected clients
			for(int i = 0; i < keys.size(); i++)
			{
				//get the client thread for this client
				ClientThread t = clients.get(keys.get(i));

				try
				{
					t.out.writeObject(gi);
					t.out.reset();
				}
				catch(Exception e)
				{
					System.out.println("failed to update client: " + keys.get(i));
				}
			}
		}
		
		void doGameover(GameInfo gi, int gs)
		{
			//if the player won
			if(gs == 1)
			{
				//increment the players score
				clientInfo.put(clientNum, (clientInfo.get(clientNum) + 1));
				
				//inform client they won
				gi.turn = -1; //indicates the client won
				try //send object to client
				{	
					this.out.writeObject(gi);
					this.out.reset();
				}
				catch(Exception e2)
				{
					System.out.println("error informing player " + clientNum + " they won: " + e2);
				}
				
				//put in server log that client won
			    listUpdate.accept("player " + clientNum + " won");
				
				//update server list with client score
				guiUpdate.accept(clientInfo);
				
				//update all clients top 3 leaderboard
				gi.turn = -4; //indicates its just a leaderboard update to clients
				gi.top3 = getTop3();
				sendToAll(gi);
			}
			
			//if the server won
			else if(gs == 2)
			{
				//put in server log that client lost
			    listUpdate.accept("player " + clientNum + " lost");
				
				//inform the client they lose
				gi.turn = -2; //indicates the client won
				try //send object to client
				{	
					this.out.writeObject(gi);
					this.out.reset();
				}
				catch(Exception e2)
				{
					System.out.println("error informing player " + clientNum + " they lost: " + e2);
				}
			}
			
			//it was a draw
			else if(gs == 3)
			{
				//put in server log that client tied
			    listUpdate.accept("player " + clientNum + " tied");
				
				//inform the player they tied
				gi.turn = -3; //indicates the client tied
				try //send object to client
				{	
					this.out.writeObject(gi);
					this.out.reset();
				}
				catch(Exception e2)
				{
					System.out.println("error informing player " + clientNum + " they tied: " + e2);
				}
			}
		}
		
		public void run()
		{	
			try 
			{
				in = new ObjectInputStream(connection.getInputStream());
				out = new ObjectOutputStream(connection.getOutputStream());
				connection.setTcpNoDelay(true);	
			}
			catch(Exception e) 
			{
				System.out.println("Streams not open");
			}
			
			synchronized(clients)
			{
				//record that this client connected in server log
				listUpdate.accept("client " + clientNum + " connected");
				
				//create an initial game info object to send to client and update
				GameInfo gi = new GameInfo(clientNum);
				gi.board = getBlankBoard(); //create an empty board to send to client initially	
				gi.top3 = getTop3(); //list of top 3 clients
				gi.turn = -5; //turn of -5 tells client that theyre being assigned a number
				
				guiUpdate.accept(clientInfo); //update server gui
				
				//send object to client
				try
				{	
					this.out.writeObject(gi);
					this.out.reset();
				}
				catch(Exception e2)
				{
					System.out.println("error performing initial write to client " + clientNum + ": " + e2);
				}
			}
			
			while(true) 
			{
				try
				{	
					//read in from client
					GameInfo gi = (GameInfo) in.readObject();
					
					synchronized(clients)
					{	
						//if the client is replaying
						if(gi.turn == -10)
						{
							//create an initial game info object to send to client
							GameInfo freshgame = new GameInfo(clientNum);
							freshgame.board = getBlankBoard(); //create an empty board to send to client initially	
							freshgame.top3 = getTop3(); //list of top 3 clients
							
							//send object to client
							try
							{	
								this.out.writeObject(freshgame);
								this.out.reset();
							}
							catch(Exception e2)
							{
								System.out.println("error performing initial write to client " + clientNum + ": " + e2);
							}
							
						}
						
						else
						{
							//check to see if client won
							int gs = checkGameStatus(gi.board);
							if(gs > 0)
								doGameover(gi, gs);
							
							//if its the server's turn
							if(gi.turn == 1)
							{
								//indicate its now the players turn
								gi.turn = 0;
								
								if(gi.diff == 1)
								{
									int next;
									synchronized(nextMove)
									{
										//get the board position of next move from findnextmove
										next = nextMove.getEasyMove(gi.board);
									}
									
									//update the move in the game info and send a message to the server log
									gi.board[next] = "X";
									listUpdate.accept("against client " + clientNum + " (difficulty: easy): " + " playing position " + next);
								}
								else if(gi.diff == 2)
								{
									int next;
									synchronized(nextMove)
									{
										//get the board position of next move from findnextmove
										next = nextMove.getMediumMove(gi.board);
									}
									
									//update the board in the game info and send a message to server log
									gi.board[next] = "X";
									listUpdate.accept("against client " + clientNum + " (difficulty: med): " + " playing position " + next);
								}
								else
								{
									int next;
									synchronized(nextMove)
									{
										//get the board position of next move from findnextmove
										next = nextMove.getExpertMove(gi.board);
									}
									
									//update the board in the game info and send a message to the server log
									gi.board[next] = "X";
									listUpdate.accept("against client " + clientNum + " (difficulty: expert): " + " playing position " + next);
								}
								
								
								//send object to client
								try
								{	
									this.out.writeObject(gi);
									this.out.reset();
								}
								catch(Exception e2)
								{
									System.out.println("error sending server move to client " + clientNum + ": " + e2);
								}
								
								//check to see if server won with this move
								gs = checkGameStatus(gi.board);
								if(gs > 0)
									doGameover(gi, gs);
								
							}
						}
					}
					
				}
				catch(Exception e)
				{
					//update server log to say client disconnected
					listUpdate.accept("client " + clientNum + " disconnected");
					
					//update the clientinfo hashmap to reflect that client disconnected
					clientInfo.remove(clientNum);
					clients.remove(clientNum);
					
					//create a dummy gameinfo to send clientinfo to update the gui with
					GameInfo toUpdate = new GameInfo(0);
					toUpdate.turn = -4; //indicates that info is just a top 3 list update
					toUpdate.top3 = getTop3(); //get most recent top 3 list
					
					//update server client list
					guiUpdate.accept(clientInfo);
					
					//send to clients so they can update their top3
					sendToAll(toUpdate);
					
					//add the clients id number to the array list so it can be reused
					addToIDs(clientNum);
					
					break;
				}
				
				
			}
		}
	}
}


	
	

	
