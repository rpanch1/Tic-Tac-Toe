

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

public class TTTServerGUI extends Application
{
	public static void main(String[] args) 
	{
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		//load in the fxml file for the first scene
		FXMLLoader loader1 = new FXMLLoader(getClass().getResource("/fxml/serverStart.fxml"));
		loader1.setController(new StartController()); //set controller for the scene
		Scene startScene = new Scene(loader1.load(), 600, 400);
		//StartController startController = loader1.getController();
		
        primaryStage.setTitle("tic tac toe server");
        
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() 
		{
            @Override
            public void handle(WindowEvent t) 
            {
                Platform.exit();
                //System.exit(0);
            }
        }); 
		
		//put the scene on the stage and show it
		primaryStage.setScene(startScene);
		primaryStage.setResizable(false);
		primaryStage.show();
		
	}

}
