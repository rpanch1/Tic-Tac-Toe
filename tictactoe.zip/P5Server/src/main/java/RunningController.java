import javafx.fxml.FXML;
import javafx.scene.control.ListView;

public class RunningController 
{
	//load in the elements from the fxml file
	@FXML
	ListView<String> clientList;
	@FXML
	ListView<String> serverLog;
	
}
