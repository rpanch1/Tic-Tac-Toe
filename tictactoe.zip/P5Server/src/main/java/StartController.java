
import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.function.Consumer;

public class StartController 
{
	TTTServer serverConnection;
	
	RunningController runController;
	Scene runningScene;
	
	//retrieve elements from start scene fxml
    @FXML
    Button servStartBtn;
    @FXML
    TextField portField;
    @FXML
    Label errorLabel;
    
	public void handleButton()
	{
		//load the second scene
		try
		{	
			//load gameplay scene
			FXMLLoader loader1 = new FXMLLoader(getClass().getResource("/fxml/serverRunning.fxml"));
			loader1.setController(new RunningController());
			runningScene = new Scene(loader1.load(), 600, 400);
			runController = loader1.getController();
		}
		catch(Exception e) 
		{
			System.out.println("could not load fxml file");
		}
		
		//create a pause transition for when a connection is successful
		PauseTransition successfulLaunch = new PauseTransition(Duration.seconds(2));
		successfulLaunch.setOnFinished(event -> {
			
			//set scene to gameplay scene
	    	Stage primaryStage = (Stage) servStartBtn.getScene().getWindow();
	    	primaryStage.setScene(runningScene);
	    	
		});
		
		//create a pause transition for when a connection is unsuccessful
		PauseTransition failedLaunch = new PauseTransition(Duration.seconds(3));
		failedLaunch.setOnFinished(event -> {errorLabel.setText("");});
				
		//consumer that implements run later for if the connection was successful
		Consumer<Serializable> success = data -> Platform.runLater(()-> {
			
			//notify user that the connection was successful
			errorLabel.setText("server successfully launched!");
			
			//move to the gameplay scene
			successfulLaunch.play();
			
		});
		
		//consumer that implements runlater for if the connection failed
		Consumer<Serializable> fail = data -> Platform.runLater(()-> {
			
			//notify the user that the connection was not successful
			errorLabel.setText("could not start the server");
			
			//clear text fields and wait for user to retry or exit
			portField.clear();
			
			//remove the error message
			failedLaunch.play();
			
		});
		
		//consumer to handle update of gui
		Consumer<HashMap<Integer, Integer>> guiUpdate = clientList -> Platform.runLater(()-> {
			
			
			//get the keys for the clients in client status hashmap
			ArrayList<Integer> keys = new ArrayList<Integer>(clientList.keySet());
			
			//clear the current client list
			runController.clientList.getItems().clear();
			
			//check all the client statuses and count the number that are connected still and the
			//number that are in a game
			for(int i = 0; i < keys.size(); i++)
			{
				//add this client to the list view as waiting for game
				runController.clientList.getItems().add("player " + keys.get(i) + ": " + clientList.get(keys.get(i)));
			}
			
		});
		
		//consumer to handle updating of server log list view
		Consumer<String> listUpdate = message -> Platform.runLater(()-> {
		
			runController.serverLog.getItems().add(message);
			
		});
		
		
				
		//create a connection to the server
		try
		{
			serverConnection = new TTTServer(success, fail, guiUpdate, listUpdate, Integer.parseInt(portField.getText()));
		}
		catch(Exception e)
		{
			errorLabel.setText("enter a valid port number");
		}
    	
	}
}
