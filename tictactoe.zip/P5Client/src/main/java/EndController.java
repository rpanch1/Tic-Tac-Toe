import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class EndController 
{
	Scene playScene;
	Scene diffScene;
	ConnectController connectController;
	
	@FXML
	Label outcomeLabel;
	@FXML
	Button replayBtn;
	@FXML
	Button quitBtn;
	
	public void handleReplay()
	{
		//send the server a game object indicating a fresh game
		
		GameInfo freshgame = connectController.clientConnection.gameInfo;
		
		freshgame.turn = -10; //indicates replaying
		
		connectController.clientConnection.send(freshgame);
		
		//go to difficulty selection screen
		Stage pStage = (Stage) replayBtn.getScene().getWindow();
		pStage.setScene(diffScene);
	}
	
	public void handleQuit()
	{
		Platform.exit();
        //System.exit(1);
	}
}
