import java.io.Serializable;
import java.util.HashMap;

public class GameInfo implements Serializable
{
	
	private static final long serialVersionUID = 3728377336918063065L;
	GameInfo(int num)
	{
		playerNum = num;
	}
	
	String[] board;
	HashMap<Integer, Integer> top3; //key is client number, value is score
	int playerNum;
	int turn; //0 if player, 1 if server
	int diff; //1 is easy, 2 is medium, 3 is expert
	
}
