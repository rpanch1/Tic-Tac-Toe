import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class PlayController 
{
	TTTClient clientConnection;
	Scene inGameScene;
	Scene endScene;
	
	//controller so that the play scene controller can access connect scene controller
	ConnectController connectController;
	
	GameInfo gi;
	
	//retrieve elements from gameplay scene fxml file
    @FXML
    ImageView TL; //top left 
    @FXML
    ImageView TM; //top middle
    @FXML
    ImageView TR; //top right
    @FXML
    ImageView ML; //middle left
    @FXML
    ImageView MM; //middle middle
    @FXML
    ImageView MR; //middle right
    @FXML
    ImageView BL; //bottom left
    @FXML
    ImageView BM; //bottom middle
    @FXML
    ImageView BR; //bottom right
    @FXML
    ListView<String> topPlayers;
    @FXML
    Label playerNum;
    @FXML
    Label turnLabel;
    
    PlayController()
    {    	
    }
    

    public void handleTL()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[0].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[0] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		TL.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleTM()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[1].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[1] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		TM.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleTR()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[2].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[2] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		TR.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleML()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[3].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[3] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		ML.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleMM()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[4].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[4] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		MM.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleMR()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[5].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[5] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		MR.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleBL()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[6].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[6] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		BL.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleBM()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[7].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[7] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		BM.setImage(new Image("/O.png"));
    	}
    }
    
    public void handleBR()
    {
    	gi = connectController.clientConnection.gameInfo;
    	
    	//only count click if this space is empty
    	if(gi.turn == 0 && gi.board[8].equals("b"))
    	{
    		//indicate its now servers turn
    		gi.turn = 1;
    		turnLabel.setText("it's the server's turn");
    		
    		//update the space to be an O
    		gi.board[8] = "O";
    		
    		//send to server
    		connectController.clientConnection.send(gi);
    		
    		//update clients own gui as well
    		BR.setImage(new Image("/O.png"));
    	}
    }
	
}
