import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.util.function.Consumer;
import java.io.Serializable;
import java.util.ArrayList;

public class ConnectController
{
	TTTClient clientConnection;
	
	//controller so that first scene controller can access second scene
	PlayController playController;
	Scene playScene;
	
	//controller so that connect scene can access difficulty screen 
	DifficultyController diffController;
	Scene diffScene;
	
	//controller so that the connect scene can access the end screen
	EndController endController;
	Scene endScene;
	
	GameInfo gi;
	
	//retrieve the gui elements from start scene fxml file
	@FXML
	TextField ipField;
	@FXML
	TextField portField;
	@FXML
	Button connectBtn;
	@FXML
	Label errorLabel;
    
    ConnectController()
    {    	
    }
    
	public void handleConnectButton()
	{	
		//create a pause transition for when a connection is successful
		PauseTransition successfulConnect = new PauseTransition(Duration.seconds(2));
		successfulConnect.setOnFinished(event -> {
			
			playController.playerNum.setText("you're player " + clientConnection.myNumber);
			
			//set scene to choose scene
	    	Stage primaryStage = (Stage) connectBtn.getScene().getWindow();
	    	primaryStage.setScene(diffScene);
			
		});
		
		//create a pause transition for when a connection is unsuccessful
		PauseTransition failedConnect = new PauseTransition(Duration.seconds(3));
		failedConnect.setOnFinished(event -> {errorLabel.setText("");});
		
		PauseTransition gameover = new PauseTransition(Duration.seconds(2));
		gameover.setOnFinished(event -> {
			
			//set the text at the game over scene to reflect game outcome
			if(gi.turn == -1) endController.outcomeLabel.setText("you won!");
			else if(gi.turn == -2) endController.outcomeLabel.setText("you lost.");
			else if(gi.turn == -3) endController.outcomeLabel.setText("you tied.");
			
			//change scene to end of game scene
			Stage pStage = (Stage) playController.turnLabel.getScene().getWindow();
			pStage.setScene(endScene);
		});
		
		PauseTransition updateTiles = new PauseTransition(Duration.seconds(1));
		updateTiles.setOnFinished(event -> {
			
			if(gi.turn >= 0)
			{
				//update the turn label
				playController.turnLabel.setText("it's your turn");
			}
			
			//update each tile to most recent play
			playController.TL.setImage(new Image("/" + gi.board[0] + ".png"));
			playController.TM.setImage(new Image("/" + gi.board[1] + ".png"));
			playController.TR.setImage(new Image("/" + gi.board[2] + ".png"));
			playController.ML.setImage(new Image("/" + gi.board[3] + ".png"));
			playController.MM.setImage(new Image("/" + gi.board[4] + ".png"));
			playController.MR.setImage(new Image("/" + gi.board[5] + ".png"));
			playController.BL.setImage(new Image("/" + gi.board[6] + ".png"));
			playController.BM.setImage(new Image("/" + gi.board[7] + ".png"));
			playController.BR.setImage(new Image("/" + gi.board[8] + ".png"));
			
			playController.TL.setDisable(false);
			playController.TM.setDisable(false);
			playController.TR.setDisable(false);
			playController.ML.setDisable(false);
			playController.MM.setDisable(false);
			playController.MR.setDisable(false);
			playController.BL.setDisable(false);
			playController.BM.setDisable(false);
			playController.BR.setDisable(false);
			
		});
		
		//consumer to handle updating the play scene with info from a passed gameinfo object
		Consumer<Serializable> guiUpdate = gameInfo -> Platform.runLater(()-> {
			
			gi = (GameInfo) gameInfo;
				
			//if the game is over, start game over sequence
			if(gi.turn == -1 || gi.turn == -2 || gi.turn == -3)
			{
				//update the in game label to display winner
				if(gi.turn == -1)
				{
					playController.turnLabel.setText("you won!");
					endController.outcomeLabel.setText("you won!");
				}
				else if(gi.turn == -2)
				{
					playController.turnLabel.setText("you lost!");
					endController.outcomeLabel.setText("you lost!");
				}
				else if(gi.turn == -3)
				{
					playController.turnLabel.setText("it's a tie!");
					endController.outcomeLabel.setText("you tied.");
				}
				
				gameover.play();
			}
			
			//otherwise update the gameboard with any new moves
			else
			{
				playController.TL.setDisable(true);
				playController.TM.setDisable(true);
				playController.TR.setDisable(true);
				playController.ML.setDisable(true);
				playController.MM.setDisable(true);
				playController.MR.setDisable(true);
				playController.BL.setDisable(true);
				playController.BM.setDisable(true);
				playController.BR.setDisable(true);
				
				//update the tiles to most recent game board
				//(with delay so game play looks natural)
				updateTiles.play();
			}
			
		});
		
		//consumer to update the top3 list view
		Consumer<Serializable> top3 = gameInfo -> Platform.runLater(()-> {
			
			gi = (GameInfo) gameInfo;
				
			//clear previous list
			playController.topPlayers.getItems().clear();
			
			//get the keys for the clients in client status hashmap
			ArrayList<Integer> keys = new ArrayList<Integer>(gi.top3.keySet());
			
			//add new list to the listview
			for(int i = 0; i < keys.size(); i++)
			{
				int thisKey = keys.get(i);
				
				playController.topPlayers.getItems().add("player " + thisKey + ": " + gi.top3.get(thisKey));
			}
			
		});
		
		//consumer that implements run later for if the connection was successful
		Consumer<Serializable> success = data -> Platform.runLater(()-> {
			
			//notify user that the connection was successful
			errorLabel.setText("connected to server!");
			
			//move to the game play scene
			successfulConnect.play();
			
		});
		
		//consumer that implements run later for if the connection failed
		Consumer<Serializable> fail = data -> Platform.runLater(()-> {
			
			//notify the user that the connection was not successful
			errorLabel.setText("could not connect to the server");
			
			//clear text fields and wait for user to retry or exit
			ipField.clear();
			portField.clear();
			
			//remove the error message
			failedConnect.play();
			
		});
		
		try
		{
			//create a new connection
			clientConnection = new TTTClient(success, fail, guiUpdate, top3, ipField.getText(), Integer.parseInt(portField.getText()));
			
			clientConnection.setDaemon(true);
			
			//start the connection
			clientConnection.start();
		}
		catch(Exception e)
		{
			errorLabel.setText("please enter a valid ip and a valid port");
		}
		
		//load other scenes
		try
		{	
			//load difficulty scene
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/clientDifficulty.fxml"));
			loader.setController(new DifficultyController());
			diffScene = new Scene(loader.load(), 800, 550);
			diffController = loader.getController();

			//load the client playing scene
			FXMLLoader loader2 = new FXMLLoader(getClass().getResource("/fxml/clientPlay.fxml"));
			loader2.setController(new PlayController());
			playScene = new Scene(loader2.load(), 800, 550);
			
			//load the end of game scene
			FXMLLoader loader3 = new FXMLLoader(getClass().getResource("/fxml/clientEnd.fxml"));
			loader3.setController(new EndController());
			endScene = new Scene(loader3.load(), 800, 550);
			
			//get the controller for the end scene
			endController = loader3.getController();
			endController.connectController = this;
			endController.playScene = playScene;
			endController.diffScene = diffScene;
			
			//get the controller for the play scene
			playController = loader2.getController();
			playController.connectController = this;
			
			//set the difficulty controllers play scene to the newly loaded scene
			diffController.playScene = playScene;
			diffController.connectController = this;
		}
		catch(Exception e) 
		{
			System.out.println("could not load fxml file: " + e);
		}
		
    	 
	}
	
}