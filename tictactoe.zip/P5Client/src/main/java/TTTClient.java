import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.util.function.Consumer;

public class TTTClient extends Thread
{
	Socket socketClient;
	
	ObjectOutputStream out;
	ObjectInputStream in;
	
	//client identification number provided by the server
	int myNumber;
	
	//ip address and port to be set by user
	String ipAddress;
	int portNumber;
	
	//client side instance of gameinfo to store most recent info received from server
	GameInfo gameInfo;
	
	//consumer to update the gui with new game information
	private Consumer<Serializable> guiUpdate;
	
	//consumer to update the top3 listview with new players
	private Consumer<Serializable> top3;
	
	//consumers with runnables for updating the gui based on connection outcome
	private Consumer<Serializable> successRun;
	private Consumer<Serializable> failRun;
	
	//represents the difficulty chosen by the client
	// easy = 1 / medium = 2 / expert = 3
	int difficulty;
	
	TTTClient(Consumer<Serializable> success, Consumer<Serializable> fail, Consumer<Serializable> playgui, Consumer<Serializable> three, String ip, int port)
	{
		ipAddress = ip;
		portNumber = port;
		
		successRun = success;
		failRun = fail;
	
		guiUpdate = playgui;
		top3 = three;
	}
	
	public void run()
	{
		
		try 
		{
			//create connection to server
			socketClient= new Socket(ipAddress, portNumber);
			out = new ObjectOutputStream(socketClient.getOutputStream());
			in = new ObjectInputStream(socketClient.getInputStream());
			socketClient.setTcpNoDelay(true);
			
			//run the consumer runnable to update gui for a successful connection
			successRun.accept(1);
			
		}
		catch(Exception e) 
		{
			//update gui for failed connection if there was an exception
			failRun.accept(1);
		}
		
		while(true) 
		{
		
			try 
			{	
				//read in the current game information form the server
				GameInfo gi = (GameInfo) in.readObject();
				
				//if turn is -4, then only update the top3 list
				if(gi.turn == -4)
				{
					top3.accept(gi);
				}
				
				else
				{
					gameInfo = gi; //update gameInfo to most recent from server to be accessed elsewhere
					
					//if turn is -5, then being assigned a number
					if(gi.turn == -5)
					{
						myNumber = gi.playerNum;
						top3.accept(gi);
						
						//set the turn to be the players, as they start
						gi.turn = 0;
					}
					
					//update player gui with new game info
					guiUpdate.accept(gi);
				}
				
			}
			catch(Exception e) //connection to server failed
			{
				System.out.println("connection to server dropped!");
				
			}
		}
	
    }
	
	public void send(GameInfo gi) 
	{
		
		try 
		{
			//update difficulty before sending to server each time
			gi.diff = difficulty;
			
			out.writeObject(gi);
			out.reset();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}


}
