import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.fxml.FXMLLoader;

public class TTTClientGUI extends Application
{
	public static void main(String[] args) 
	{
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		//load the scene from the fxml file and set the controller
		FXMLLoader loader1 = new FXMLLoader(getClass().getResource("/fxml/clientStart.fxml"));
		loader1.setController(new ConnectController());
		Scene startScene = new Scene(loader1.load(), 800, 550);
		
		primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() 
		{
            @Override
            public void handle(WindowEvent t) 
            {            	
                Platform.exit();
                //System.exit(1);
            }
        });
		
        primaryStage.setTitle("tic tac toe client");
		
		primaryStage.setScene(startScene);
		primaryStage.setResizable(false);
		primaryStage.show();
		
	}

}
