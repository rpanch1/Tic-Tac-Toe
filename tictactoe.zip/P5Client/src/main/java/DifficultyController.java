import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class DifficultyController 
{
	//scene of game play to switch to when diff is selected
	Scene playScene;
	
	//in order to access componenets of the connect controller
	ConnectController connectController;
	
	@FXML
	Label diffPrompt;
	@FXML
	Button easyBtn;
	@FXML
	Button medBtn;
	@FXML
	Button expertBtn;
	
	//handle click of easy button
	public void handleEasy()
	{
		//set the difficulty for the client
		connectController.clientConnection.difficulty = 1;
		
		Stage pStage = (Stage) easyBtn.getScene().getWindow();
		pStage.setScene(playScene);
	}
	
	//handle click of medium button
	public void handleMed()
	{
		//set the difficulty for the client
		connectController.clientConnection.difficulty = 2;
		
		Stage pStage = (Stage) medBtn.getScene().getWindow();
		pStage.setScene(playScene);
	}
	
	//handle click of expert button
	public void handleExp()
	{
		//set the difficulty for the client
		connectController.clientConnection.difficulty = 3;
		
		Stage pStage = (Stage) expertBtn.getScene().getWindow();
		pStage.setScene(playScene);
	}
}
